$( document ).ready(function() {
    
    // Write your custom Javascript codes here...
    
});
